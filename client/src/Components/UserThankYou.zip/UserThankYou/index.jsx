import React from 'react';
import { useNavigate } from 'react-router-dom';
import './index.css';
import plato_image from '../Assets/plato image.jpeg';

const ThankYou = (props) => {
  const navigate = useNavigate()
  const {consultantDetails} = props
  // console.log(consultantDetails)
  // console.log(typeof(consultantDetails))
  // console.log(consultantDetails.basicdetails) 
  return (
    <div className="thank-you-container90">
      <div className='heading-container90'>
      <h1 className="user-thank-you-form-heading">
        <span>Your request has been accepted by </span>
        <span className="user-thank-you-name">{consultantDetails.basicdetails[0].firstName} {consultantDetails.basicdetails[0].lastName}</span>  
        {/* <span className="user-thank-you-name">JohnDoe</span> */}
      </h1>
      </div> 
      <div className="thank-you">
        <div className="thank-you-inner">
          <img src={plato_image} alt="John Doe" className="image"/>
           <h3 className="john-doe-name">{consultantDetails.basicdetails[0].firstName} {consultantDetails.basicdetails[0].lastName}</h3> 
          {/* <h3 className="john-doe-name">John Doe</h3> */}
          <div className="frame-div1">
             {consultantDetails.basicdetails[0].industry.map(e=>(
              <button className="resource-operations-label">
                {e.label}
              </button>
            ))} 
          </div>
          <div className="frame-div1">
           <button className="resource-operations-label">
              {consultantDetails.basicdetails[0].functionName}
            </button> 
            {/* <button className="resource-operations-label">
              Operations
            </button> */}
          </div>
          <div className="user-thank-you-additional-info">
            {/* <p><span className='user-thank-you-span'>Estimated wait time</span>: 2min</p> */}
            <p><span className='user-thank-you-span'>Meeting duration</span>60 min</p>
          </div>
          <div className="user-thank-you-action-buttons">
            <button className="action-button join-call">Join Call</button>
            <button className="action-button view-profile" onClick={()=>navigate(`/consultant-profile/${consultantDetails._id}`)}>View Consultant Profile</button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ThankYou;
